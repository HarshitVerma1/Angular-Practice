import { Component } from "@angular/core";

@Component({
  selector: "newComp",
  templateUrl: "./newComp.component.html",
  // styleUrl: "../../styles.css"
})
export class NewComp {
  my_name = '';
  my_password = '';

  onUpdateUsername(event: any) {
    this.my_name = (<HTMLInputElement>event.target).value;
  }
}
